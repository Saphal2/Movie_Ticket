package Model;

public class Main_Cat {

    String sitting_arrangement;

    public Main_Cat(String sitting_arrangement) {
        this.sitting_arrangement = sitting_arrangement;
    }

    public String getSitting_arrangement() {
        return sitting_arrangement;
    }

    public void setSitting_arrangement(String sitting_arrangement) {
        this.sitting_arrangement = sitting_arrangement;
    }
}