package Model;

import java.util.ArrayList;

public class Ticket {
    ArrayList<User> User;
    ArrayList<Seat> Seat;

    public Ticket(ArrayList<Model.User> user, ArrayList<Model.Seat> seat) {
        User = user;
        Seat = seat;
    }

    public ArrayList<Model.User> getUser() {
        return User;
    }

    public void setUser(ArrayList<Model.User> user) {
        User = user;
    }

    public ArrayList<Model.Seat> getSeat() {
        return Seat;
    }

    public void setSeat(ArrayList<Model.Seat> seat) {
        Seat = seat;
    }
}