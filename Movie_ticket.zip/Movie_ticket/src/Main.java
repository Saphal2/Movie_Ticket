
import Model.Movie;
import Model.Seat;
import Model.Ticket;
import Model.User;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Movie m1=new Movie("Sofa", "Family", "Boss Baby", "11:45 pm", "Rs. 500");
        Movie m2=new Movie("Seat", "Horror", "Kantara", "11:00 am", "Rs. 170");
        Movie m3=new Movie("Seat", "Social Drama", "Chakka Panja 4", "9:45 am", "Rs. 100");
        Movie m4=new Movie("Sofa", "Adventure", "Avatar: The Way of Water", "4:20 pm", "Rs. 410");
        ArrayList<Movie> mo1 = new ArrayList<>();
        ArrayList<Movie> mo2 = new ArrayList<>();
        mo1.add(m1);
        mo2.add(m4);
        User u1=new User("Moti ", "Aakashedhara","9");
        User u2=new User("coffee", "Bouddha", "8");
        User u3=new User("Tea", "Sanobharyang", "4");
        User u4=new User("Minky", "Swayambhu", "1");
        ArrayList<User> us1 = new ArrayList<>();
        ArrayList<User> us2 = new ArrayList<>();
        ArrayList<User> us3 = new ArrayList<>();
        ArrayList<User> us4 = new ArrayList<>();

        us1.add(u1);
        us2.add(u2);
        us3.add(u3);
        us4.add(u4);

        Seat s1=new Seat("J", "1");
        Seat s2=new Seat("H", "3");
        Seat s3=new Seat("I", "5");

        Ticket t1=new Ticket(us1, s1);
        Ticket t2=new Ticket(us2, s2);






    }
}